#include <iostream>
#include <curl/curl.h>
#include <vector>
#include <string>
#include <fstream>
#include <map>
#include <boost/regex.hpp>
using namespace std;

string main_url = "http://codetrio.com/stanmore/";
ofstream outfile;

// This is the writer call back function used by curl

int writer(char *data, size_t size, size_t nmemb, std::string *buffer) {
  int result = 0;
  if (buffer != NULL) {
    buffer->append(data, size * nmemb);
    result = size * nmemb;
  }
  return result;
}
void curl_init_func(string url, string& buffer){

curl_global_init( CURL_GLOBAL_ALL );
CURL * myHandle;
CURLcode result; // We�ll store the result of CURL�s webpage retrieval, for simple error checking.
myHandle = curl_easy_init ( ) ;
// Notice the lack of major error checking, for brevity
curl_easy_setopt(myHandle, CURLOPT_URL, url.data());

curl_easy_setopt(myHandle, CURLOPT_WRITEFUNCTION, writer);
curl_easy_setopt(myHandle, CURLOPT_WRITEDATA, &buffer);

curl_easy_perform( myHandle );
curl_easy_cleanup( myHandle );

}


int AsciiToInteger(string Str)
{
    int total = 0;

    for (int i=0;i<Str.length();i++)
        total += (int)Str.at(i);

   return total;
}

bool find_substr(string* victim,string targets){
string found_target;
    if( victim->find(targets) != string::npos ){
        //cout << "found" << endl;
        return true;
        }
    else
        {
        //cout << "not found" <<endl;
        return false;
        }


}



void delete_substr(string* str, string start_tag,string end_tag){
 if(find_substr(str,start_tag))
     str->erase(str->find(start_tag),str->find(end_tag)+end_tag.length());

}

string scrape_between(string* str, string start_tag, string end_tag,int start_erase_pos=0){

  string str3 = str->erase(start_erase_pos,str->find(start_tag)+start_tag.length());

  string str4 = str3.substr(start_erase_pos,str->find(end_tag));

  //cout << str4 << endl;
return str4;

}




bool has_visited (map<int,int>& all_visited_links,int current_link){

          //if (std::binary_search (all_visited_links->begin(), all_visited_links->end(), current_link))

            if (all_visited_links.count(current_link)>0)
             return true;

     return false;

}


void check_func (vector<string>* all_saved_links,map<int,int>& all_visited_links,string cat_link,string& buffer_curl){

     int asc_val = AsciiToInteger(cat_link);

  if(!has_visited(all_visited_links,asc_val)){
        //check if external link ....
        if(find_substr(&cat_link,main_url)){
            if(cat_link.at(0)=='h'){

                curl_init_func(cat_link,buffer_curl);
             }else {
				curl_init_func(main_url+cat_link,buffer_curl);
              } // bring reative/phisical path....
          cout << cat_link << endl;
          outfile << cat_link << "\t" << asc_val << endl;
          all_saved_links->push_back(cat_link);
          //all_visited_links->push_back(asc_val);

          all_visited_links.insert(std::pair<int,int>(asc_val,asc_val));
        }
  }


}


void get_all_cat_links(string* str,vector<string>* all_saved_links,map<int,int>& all_visited_links){

     if(find_substr(str,"<a href=")){
     string temp = scrape_between(str,"<a href=",">");
     string cat_link = scrape_between(&temp,"\"","\"");
        if(!cat_link.empty()&&(cat_link.at(0)=='h'||cat_link.at(0)=='/')){
              string buffer_curl;
              check_func(all_saved_links,all_visited_links,cat_link,buffer_curl);
              if(!buffer_curl.empty())
              get_all_cat_links(&buffer_curl,all_saved_links,all_visited_links);

        } // is the link relative or physical
     get_all_cat_links(str,all_saved_links,all_visited_links);
     } // is there any link in this page
}



void links(string* str,vector<string>* all_saved_links){
 if(find_substr(str,"<a href=")){
     string temp = scrape_between(str,"<a href=",">");
     string cat_link = scrape_between(&temp,"\"","\"");

    all_saved_links->push_back(cat_link);
     links(str,all_saved_links);

 }


}


int main(int argc, char** argv)
{
 string buffer;
curl_init_func(main_url,buffer);

map<int,int> all_visited_links; //= new map<int>();
vector<string>* all_saved_links = new vector<string>();
 //all_saved_links->push_back(main_url);
 //all_visited_links->push_back(AsciiToInteger(main_url));

//cout << buffer << endl;

 //all_visited_links->push_back(3685);
 //all_visited_links->push_back(4780);

//cout << !has_visited(all_visited_links,3685) << endl;

outfile.open("animesh.txt");


int asc_val = AsciiToInteger(main_url);
all_visited_links.insert(std::pair<int,int>(asc_val,asc_val));
outfile << main_url << "\t" << asc_val << endl;


get_all_cat_links(&buffer,all_saved_links,all_visited_links);

//links(&buffer,all_saved_links);
cout<< all_saved_links->size()<<endl;



//string target = "http://www.codetrio.com/wp-content/uploads/2013/04/expressionengine-logo-blue-e1369025458792.png";
//cout << find_substr(&target,main_url)<<endl;

/*

for(std::vector<string>::const_iterator cit = all_saved_links->begin(), e = all_saved_links->end();
    cit != e;  ++cit)
{

       outfile  << *cit << endl;
}
*/
   outfile.close();
 

return 0;
}

