#include <iostream>
//#include <boost/regex.hpp>
#include <iostream>
#include <string>
#include <curl/curl.h>
//#include <boost/regex.hpp>  // Boost.Regex lib
#include <winbase.h>
#include <vector>
#include <map>
#include <fstream>
#include < algorithm >
#include <sstream>
//#using <mscorlib.dll>
//#using <System.dll>
#using <System.Web.dll>

#include <utility>
#include <iterator>
#include "msclr\marshal.h"
using namespace System;
using namespace System::Web;
using namespace std;
using namespace std;

string main_url;
int sleep_time;

ofstream outfile_link;
ofstream outfile_data;
map<int,int> all_visited_links; //= new map<int>();
vector<string>* all_saved_links = new vector<string>();


vector<string> split(const string& s, const string& delim, const bool keep_empty = true) {
    vector<string> result;
    if (delim.empty()) {
        result.push_back(s);
        return result;
    }
    string::const_iterator substart = s.begin(), subend;
    while (true) {
        subend = search(substart, s.end(), delim.begin(), delim.end());
        string temp(substart, subend);
        if (keep_empty || !temp.empty()) {
            result.push_back(temp);
        }
        if (subend == s.end()) {
            break;
        }
        substart = subend + delim.size();
    }
    return result;
}

string get_last_elem(vector<string> splitted_elem){

	 if(splitted_elem.back().length()<1)
	  splitted_elem.pop_back();

     return splitted_elem.back();

}

int last_address_length(string cat_link){
          
	 return get_last_elem(split(cat_link,"/")).length();

}


bool find_substr(string* victim,string targets){
string found_target;
    if( victim->find(targets) != string::npos ){
        //cout << "found" << endl;
        return true;
        }
    else
        {
        //cout << "not found" <<endl;
        return false;
        }


}

void delete_substr(string* str, string start_tag,string end_tag){
 if(find_substr(str,start_tag))
     str->erase(str->find(start_tag),str->find(end_tag)+end_tag.length());

}

string scrape_between(string* str, string start_tag, string end_tag,int start_erase_pos=0){

  string str3 = str->erase(start_erase_pos,str->find(start_tag)+start_tag.length());

  string str4 = str3.substr(start_erase_pos,str->find(end_tag));

return str4;

}

void MarshalString (String ^ s, string& os) 
{
    using namespace Runtime::InteropServices;
    const char* chars = 
      (const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
    os = chars;
    Marshal::FreeHGlobal(IntPtr((void*)chars));
}
string convert_email(string email_unicode){
String^ str3 = gcnew String(email_unicode.c_str());
        str3 = HttpUtility::UrlDecode(str3);
		string temp;
		MarshalString(str3, temp);

		 return scrape_between(&temp,">","</a>");;

}

void get_all_td_from_a_tr(string* target,string start,string end,string cat_link){

	   string name_scrapped =  scrape_between(target,start,end);
	   string company_name = scrape_between (&name_scrapped,">","</a>");
      
       string city_scrapped = scrape_between(target,start,end);
	   string city_name = scrape_between (&city_scrapped,">","</a>");
       string phone_number = scrape_between(target,start,end);
       scrape_between(target,start,end);
	   string email_unicode = scrape_between(target,"<script type=\"text/javascript\">eval(unescape('","'))</script>");

       //phone_number.erase(remove_if(phone_number.begin(), phone_number.end(), isspace), phone_number.end());
	   //city_name.erase(remove_if(city_name.begin(), city_name.end(), isspace), city_name.end());
       //company_name.erase(remove_if(company_name.begin(), company_name.end(), isspace), company_name.end());
	   email_unicode = convert_email(email_unicode);
	   string category = get_last_elem(split(cat_link,"/"));

	   outfile_data << category << "\t" << company_name << "\t" << city_name << "\t" << phone_number << "\t" << email_unicode << endl;


}


void get_all_tr(string* target,string cat_link){

	if(find_substr(target,"<tr valign=\"top\">")){
    string buff =  scrape_between(target,"<tr valign=\"top\">","</tr>");
	get_all_td_from_a_tr(&buff,"<td>","</td>",cat_link);
    get_all_tr(target,cat_link); 
	  
	}

}

// This is the writer call back function used by curl
int writer(char *data, size_t size, size_t nmemb, std::string *buffer) {
  int result = 0;
  if (buffer != NULL) {
    buffer->append(data, size * nmemb);
    result = size * nmemb;
  }
  return result;
}
void curl_init_func(string url, string& buffer){

curl_global_init( CURL_GLOBAL_ALL );
CURL * myHandle;
CURLcode result; // We�ll store the result of CURL�s webpage retrieval, for simple error checking.
myHandle = curl_easy_init ( ) ;
// Notice the lack of major error checking, for brevity
curl_easy_setopt(myHandle, CURLOPT_URL, url.data());

curl_easy_setopt(myHandle, CURLOPT_WRITEFUNCTION, writer);
curl_easy_setopt(myHandle, CURLOPT_WRITEDATA, &buffer);

curl_easy_perform( myHandle );
curl_easy_cleanup( myHandle );

}


int AsciiToInteger(string Str)
{
    int total = 0;

    for (int i=0;i<Str.length();i++)
        total += (int)Str.at(i);

   return total;
}




bool has_visited (int current_link){

            if (all_visited_links.count(current_link)>0)
             return true;

     return false;

}

// check whether it is a external link or a valid relative path ...
bool check_external_relative(string cat_link, string main_url ){
   //if(find_substr(&cat_link,"html"))
    //return false;


   if(find_substr(&cat_link,main_url)&&cat_link.at(0)=='h')
	return true;
  
   if (std::count(cat_link.begin(), cat_link.end(), '/')>=3&&cat_link.at(0)=='/'&&last_address_length(cat_link)>1)
 	return true;

   return false;
}


void check_func (string cat_link,string& buffer_curl){

     int asc_val = AsciiToInteger(cat_link);

  if(!has_visited(asc_val)){
	  
    
            if(cat_link.at(0)=='h'){
                Sleep(sleep_time*1000);
                curl_init_func(cat_link,buffer_curl);
             }else {
				 //bool chk = cat_link.at(0)=='/';
	             //cout << main_url+cat_link << endl;
                Sleep(sleep_time*1000);
				curl_init_func(main_url+cat_link,buffer_curl);
              } // bring reative/phisical path....
		  //cout << cat_link << "::"<< std::count(cat_link.begin(), cat_link.end(), '/') << endl;
          outfile_link << main_url+cat_link  << endl;
          all_saved_links->push_back(cat_link);
          //all_visited_links->push_back(asc_val);

          all_visited_links.insert(std::pair<int,int>(asc_val,asc_val));
		  //all_visted_links[asc_val] =asc_val;
  }


}


void get_all_cat_links(string* str){
	
     if(find_substr(str,"<a href=")){
     string temp = scrape_between(str,"<a href=",">");
     string cat_link = scrape_between(&temp,"\"","\"");
	    if(find_substr(&cat_link,"html"))return;
         
        if(!cat_link.empty()&&check_external_relative(cat_link,main_url)){
			  string buffer_curl;
              check_func(cat_link,buffer_curl);
			  if(!buffer_curl.empty()){
              string grab_data = buffer_curl; 
              scrape_between(&grab_data,"<tr valign=\"top\">","</tr>");// remove heading ...
              get_all_tr(&grab_data,cat_link);
              get_all_cat_links(&buffer_curl);
			  }
        } // is the link relative or physical
     get_all_cat_links(str);
     } // is there any link in this page
}




int main(int argc, char** argv)
{
 
//string test = "www.bdyellowbook.com/catalog/Agricultural_Products___Services/";

//const vector<string> words = split(test, "/");
  // copy(words.begin(), words.end(), ostream_iterator<string>(cout, "\n"));

   //cout << test<<endl;

 //cout << "Please enter domain name:\n>";
//getline(cin, main_url);

//cout << "Please enter sleep time:\n>";
//std::cin >> sleep_time;


	main_url = "http://www.bdyellowbook.com";
    sleep_time = 1;


outfile_link.open("link.txt");
outfile_data.open("data.txt");

int asc_val = AsciiToInteger(main_url);
all_visited_links.insert(std::pair<int,int>(asc_val,asc_val));
outfile_link << main_url << "\t" << asc_val << endl;

 
string buffer; 
curl_init_func(main_url,buffer);

//cout << buffer << endl;
get_all_cat_links(&buffer);



cout << "size :: "<< all_saved_links->size()<<endl;

   outfile_link.close();
   outfile_data.close();
   Sleep(sleep_time*1000);

return 0;
}

